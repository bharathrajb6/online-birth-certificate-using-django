from django.contrib import messages
from django.shortcuts import render, redirect
from fpdf import FPDF
from online.models import application
def home(request):
    return render(request,'home.html')

def create(request):
    if request.method=='POST':
        name=request.POST.get('name')
        fatherName=request.POST.get('fatherName')
        motherName=request.POST.get('motherName')
        gender=request.POST.get('gender')
        pob=request.POST.get('pob')
        hospitalName=request.POST.get('hospitalName')
        address=request.POST.get('address')
        village=request.POST.get('village')
        taluk=request.POST.get('taluk')
        district=request.POST.get('district')
        state=request.POST.get('state')
        nationality=request.POST.get('nationality')
        time=request.POST.get('time')
        caste=request.POST.get('caste')
        date=request.POST.get('date')
        obj=application(child_name=name,father_name=fatherName,mother_name=motherName,gender=gender,place_of_birth=pob,
                        hospital_name=hospitalName,caste=caste,address=address,village=village,taluk=taluk,district=district,
                        state=state,nationality=nationality,dob=date,time=time)
        obj.save()

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=15)
        pdf.cell(100, 10, txt=f"Name : {name}",ln=1)
        pdf.cell(100, 10, txt=f"Father Name : {fatherName}",ln=1)
        pdf.cell(100, 10, txt=f"Mother Name : {motherName}",ln=1)
        pdf.cell(100, 10, txt=f"Date of birth : {date}",ln=1)
        pdf.cell(100, 10, txt=f"Time : {time}",ln=1)
        pdf.cell(100, 10, txt=f"Gender : {gender}",ln=1)
        pdf.cell(100, 10, txt=f"Place of birth  : {pob}",ln=1)
        pdf.cell(100, 10, txt=f"Hospital Name  : {hospitalName}",ln=1)
        pdf.cell(100, 10, txt=f"Caste  : {caste}",ln=1)
        pdf.cell(100, 10, txt=f"Address  : {address}",ln=1)
        pdf.cell(100, 10, txt=f"Village  : {village}",ln=1)
        pdf.cell(100, 10, txt=f"Taluk  : {taluk}",ln=1)
        pdf.cell(100, 10, txt=f"District  : {district}",ln=1)
        pdf.cell(100, 10, txt=f"State  : {state}",ln=1)
        pdf.cell(100, 10, txt=f"Nationality  : {nationality}",ln=1)

        pdf.output(f"{name}.pdf")
        messages.success(request,"Downloaded.")
        return redirect('home')
    else:
        return render(request,'home.html')


from django.db import models as mo

from datetime import datetime
now = datetime.now()
class application(mo.Model):
    child_name=mo.CharField(max_length=25,default='',primary_key=True)
    father_name=mo.CharField(max_length=25,default='')
    mother_name=mo.CharField(max_length=25,default='')
    gender=mo.CharField(max_length=25,default='')
    place_of_birth=mo.CharField(max_length=25,default='')
    hospital_name=mo.CharField(max_length=25,default='')
    caste=mo.CharField(max_length=20,default='')
    address=mo.TextField(max_length=100,default='')
    village=mo.CharField(max_length=25,default='')
    taluk=mo.CharField(max_length=25,default='')
    district=mo.CharField(max_length=25,default='')
    state=mo.CharField(max_length=25,default='')
    nationality=mo.CharField(max_length=25,default='')
    dob=mo.DateField(default=datetime.today())
    time=mo.TimeField(default=now.strftime("%m/%d/%Y, %H:%M:%S"))

    def __str__(self):
        return self.child_name



from django.contrib import admin
from online.models import application
# Register your models here.

admin.site.register(application)
from django.apps import AppConfig


class OnlineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'online'
